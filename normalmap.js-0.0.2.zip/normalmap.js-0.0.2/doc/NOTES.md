Ask for permission to use http://www.simonpichette.com/tileableTextures.html

pending:
- smaller lights/falloff/particles
- orbital bind light
- single pass mode
- http://shields.io/?
- release system

# References

[Physically-Based Shading at Disney](http://blog.selfshadow.com/publications/s2012-shading-course/burley/s2012_pbs_disney_brdf_slides_v2.pdf)
[Real Shading in Unreal Engine 4](https://de45xmedrsdbp.cloudfront.net/Resources/files/2013SiggraphPresentationsNotes-26915738.pdf)

# http://shields.io/
