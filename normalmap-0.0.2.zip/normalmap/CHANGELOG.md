# ![normalmap.js](gfx/logo-rendered.png)

# Changelog

## master

## 0.0.2 (2016-03-13)

* Cleaned up console.logs
* Fixed sRGB FBO initialization

## 0.0.1 (2016-03-13)

* Release with newer version of npm to prevent browserify transform mangling
* Move debounce to devDependencies


## 0.0.0 (2016-03-13)

Initial experimental public release.
